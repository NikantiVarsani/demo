
import UIKit

class FoodTableViewController: UITableViewController {
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("foods")
    //  let completion: @escaping (FoodItem?, RequestError?)
       let db=SQLiteDB.shared
    var foods = [FoodItem]()
    
    private var selectedFood: Int?
    override func viewDidLoad() {
        super.viewDidLoad()
        db.openDB()
        navigationItem.leftBarButtonItem = editButtonItem
        if let saveFood = loadFood() {
            foods += saveFood
        }
        else {
         loadSampleFood()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       }
       //table data
     override func numberOfSections(in tableView: UITableView) -> Int {
         return 1
     }
     override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return foods.count
     }
     override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cellIdentifier = "FoodTableViewCell"
         guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? FoodTableViewCell  else {
             fatalError("The dequeued cell is not an instance of FoodTableViewCell.")
         }
         let food = foods[indexPath.row]
         cell.name.text = food.name
         cell.img.image = UIImage(data: food.imagess)
         cell.rate.rating = food.rating
         return cell
     }
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
         return true
     }
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
        let id = foods[selectedFood!].id
        if selectedFood != nil {
            let deleteData = db.query(sql: "DELETE FROM fooditem WHERE id = \(id)")
            print("Successfully deleted",id)
        }
              //  foods.remove(at: indexPath.row)
                saveFood()
                tableView.deleteRows(at: [indexPath], with: .fade)
            } else if editingStyle == .insert {
            
            }
        }

        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            
            super.prepare(for: segue, sender: sender)
            
            switch(segue.identifier ?? "") {
                
           case "AddItem":
              print("Adding a new food.")
                
            case "ShowDetail":
                guard let DetailViewController = segue.destination as? ViewController else {
                    fatalError("Unexpected destination: \(segue.destination)")
                }
                
                guard let selectedCell = sender as? FoodTableViewCell else {
                    fatalError("Unexpected sender: \(String(describing: sender))")
                }
                
                guard let indexPath = tableView.indexPath(for: selectedCell) else {
                    fatalError("The selected cell is not being displayed by the table")
                }
                
                //let selectedFood = foods[indexPath.row]
            //    DetailViewController.food = selectedFood
                
            default:
                fatalError("Unexpected Segue Identifier; \(String(describing: segue.identifier))")
            }
        }
        
    @IBAction func unwindToFoodList(sender: UIStoryboardSegue) {
        if let viewData = sender.source as? ViewController,let food = viewData.food{
            
     
                  if let selectedIndexPath = tableView.indexPathForSelectedRow {
                        foods[selectedIndexPath.row] = food
                        tableView.reloadRows(at: [selectedIndexPath], with: .none)
                    }
                    else {
                        let newIndexPath = IndexPath(row: foods.count, section: 0)
                        
                        foods.append(food)
                        tableView.insertRows(at: [newIndexPath], with: .automatic)
                    }
                    saveFood()
                }
            }
            private func loadSampleFood() {
           /*  let data = db.query(sql:"select * from fooditem")
                       foods.removeAll()
                       for row in data {
                        let imagesFood = UIImageJPEGRepresentation(UIImage(named: "imageItem")!,1)
                        foods.append(FoodItem.init(name: String(describing: row["name"]!), imagess:imagesFood!, rating: Int("rate")!)!)
                            
                       }
                    print("DATA:::",foods)*/
            }
             private func saveFood() {
                do {
                    let data = try PropertyListEncoder().encode(foods)
                    let isSuccessfulSave  = NSKeyedArchiver.archiveRootObject(data, toFile: FoodTableViewController.ArchiveURL.path)
                    if isSuccessfulSave {
                    print("food successfully saved.")
                    } else {
                        print("Failed to save food...")
                    }
                } catch {
                  print("Failed to save food...")
                }
            }
           
    private func loadFood() -> [FoodItem]? {
        let data = db.query(sql:"select id,name,imageItem,rate from fooditem")
           foods.removeAll()
           for row in data {
          /*  let image : UIImage = UIImage(named: "35-handgun-png-image.png")!
            let imageData = UIImagePNGRepresentation(image)!
            let strBase64 = imageData.base64EncodedString(options: .lineLength64Characters)


            let decodeimg : NSData = NSData(base64Encoded: strBase64, options: NSData.Base64DecodingOptions(rawValue: 0))!

           // imagess.image = UIImage(data : decodeimg as Data)!

            foods.append(FoodItem.init(name: String(describing: row["name"]!), imagess:decodeimg as Data, rating: Int("name")!)!)*/
                         
            
            
            
        
           /// let imagesFood = UIImagePNGRepresentation(UIImage(data: row["imageItem"] as! Data)!)!
          //let image : UIImage = UIImage(named:"imageItem")!
            //let imageData:NSData = UIImagePNGRepresentation(image)! as NSData
           /// let strBase64 = imagesFood.base64EncodedString(options: .lineLength64Characters)
          ///  let dataDecoded:NSData = NSData(base64Encoded: strBase64, options: NSData.Base64DecodingOptions(rawValue: 0))!
           /// let decodedimage:UIImage = UIImage(data: dataDecoded as Data)!

         //   let dataDecoded:NSData = NSData(base64EncodedString: data, options: NSData.Base64DecodingOptions(rawValue: 0))!
        //    let decodedimage:UIImage = UIImage(data:Data(describing:row["imageItem"]))!

          //let imagesFood = UIImageJPEGRepresentation(UIImage(data:"imageItem")!, 1)!
            //let food: FoodItem = FoodItem(name: row["name"] as! String,imagess:row["imageItem"] as! Data,rating: row["rate"] as! Int)!

            //foods.append(food)
           // foods.append(FoodItem.init(name: String(describing: row["name"]!), imagess:imagesFood, rating: Int("name")!)!)
                
           }
        print("DATA:::",data)
        return nil
    }
  
    
}

