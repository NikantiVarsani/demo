
import UIKit
//let food: FoodItem = FoodItem(name: row["name"] as! String,imagess: row["imageItem"] as! Data,rating: row["rate"] as! Int)!

class ViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
   
    @IBOutlet weak var txtname: UITextField!
    @IBOutlet weak var images: UIImageView!
    @IBOutlet weak var ratingbar: RatingControl!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    var food: FoodItem?
    let db=SQLiteDB.shared
    private var foods = [FoodItem]()
    private var selectedFood: Int?
    override func viewDidLoad() {
    super.viewDidLoad()
        db.openDB()
        txtname.delegate = self
        if let food = food {
            navigationItem.title = food.name
            txtname.text = food.name
            images.image = UIImage(data: food.imagess)
            ratingbar.rating = food.rating
        }
        updateSaveButtonState()
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
       saveButton.isEnabled = false
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
       textField.resignFirstResponder()
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        updateSaveButtonState()
        navigationItem.title = textField.text
    }
   func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        guard let selectedImage = info[UIImagePickerControllerOriginalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        images.image = selectedImage
        dismiss(animated: true, completion: nil)
    }
    
    //MARK: Navigation
    
    @IBAction func cancel(_ sender: UIBarButtonItem) {
        let isPresentingInAddMealMode = presentingViewController is UINavigationController
        
        if isPresentingInAddMealMode {
            dismiss(animated: true, completion: nil)
        }
        else if let owningNavigationController = navigationController{
            owningNavigationController.popViewController(animated: true)
        }
        else {
            fatalError("The MealViewController is not inside a navigation controller.")
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        guard let button = sender as? UIBarButtonItem, button === saveButton else {
           print("The save button was not pressed, cancelling")
            return
        }
        let name = txtname.text ?? ""
        let photo = images.image
        let rating = ratingbar.rating
        let isSave = db.query(sql:"INSERT INTO fooditem(name,imageItem,rate) VALUES ('\(txtname.text!)','\(images.image!)','\(ratingbar.rating)')")
       // print("Successfully inserted",isSave.description)
        //food = FoodItem(name: name, imagess: UIImageJPEGRepresentation(photo!, 1)!, rating: rating)
    }
    @IBAction func selectImageFromPhotoLibrary(_ sender: UITapGestureRecognizer) {
        txtname.resignFirstResponder()
        let imagePickerController = UIImagePickerController()
        imagePickerController.sourceType = .photoLibrary
        imagePickerController.delegate = self
        present(imagePickerController, animated: true, completion: nil)
    }
    
    private func updateSaveButtonState() {
        
        if selectedFood != nil {
            let id = foods[selectedFood!]
            let isUpdate = db.query(sql: " UPDATE fooditem set name ='\(txtname.text!)' WHERE id ='\(id)' ")
           
            //tableView.reloadData()
        }
        
        let text = txtname.text ?? ""
        saveButton.isEnabled = !text.isEmpty
    }
    
}

