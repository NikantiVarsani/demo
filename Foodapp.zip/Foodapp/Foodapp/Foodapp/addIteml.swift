//
//  addItem.swift
//
//  Created by Macmini on 23/10/20.
//  Copyright © 2020 Apple Inc. All rights reserved.
//

import Foundation


struct FoodItem: Codable {
    var id:String = ""
    var name: String
    var imagess: Data
    var rating: Int
    init?(name: String, imagess: Data, rating: Int) {
        guard !name.isEmpty else {
            return nil
        }
        guard (rating >= 0) && (rating <= 5) else {
            return nil
        }
        if name.isEmpty || rating < 0  {
            return nil
        }
       
            self.name = name
            self.imagess = imagess
            self.rating = rating
    }
}

struct Summary: Codable {
    var summary: [imageset]
    struct imageset: Codable {
        var name: String
        var rating: Int
        init(_ food: FoodItem) {
            self.name = food.name
            self.rating = food.rating
        }
    }
    
    init(_ food: [String: FoodItem]) {
        summary = food.map({ imageset($0.value) })
    }
    init(_ food: [FoodItem]) {
        summary = food.map({ imageset($0) })
    }
}
